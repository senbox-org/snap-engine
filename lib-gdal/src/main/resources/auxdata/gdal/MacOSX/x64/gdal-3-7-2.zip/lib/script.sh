if ! [ -f libnss3.dylib ]; then
	cp /usr/local/Cellar/nss/3.94/lib/libnss3.dylib libnss3.dylib
fi
install_name_tool -change /usr/local/Cellar/nss/3.94/lib/libnss3.dylib @loader_path/libnss3.dylib libssl3.dylib
if ! [ -f libnssutil3.dylib ]; then
	cp /usr/local/Cellar/nss/3.94/lib/libnssutil3.dylib libnssutil3.dylib
fi
install_name_tool -change /usr/local/Cellar/nss/3.94/lib/libnssutil3.dylib @loader_path/libnssutil3.dylib libssl3.dylib